<?php
require_once './../app/News.php';
require_once __DIR__ . '/../app/Article.php';

$id = $_GET['id'];

$obj = new Article();
$data = $obj->wholePage($id);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?=$data[1]?></title>
</head>
<body>


<?php
echo $data[1] . '<hr>' . $data[2];
?>


</body>
</html>