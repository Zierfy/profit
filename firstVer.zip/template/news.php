<?php
require_once './../app/News.php';

$obj = new News;
$obj->render(__DIR__ . './../db/news.txt');
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Новости</title>
</head>
<body>

<h1>Новости</h1>
<hr>

<p>Доступные новости:</p>
<?php $obj->dispDates()?>

</body>
</html>