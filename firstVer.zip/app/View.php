<?php
class View
{
    protected $data;
    public function __construct()
    {
    }

    //сохранить данные, передаваемые в шаблон по заданному имени
    public function assign($name, $value)
    {
        $f = fopen(__DIR__ . './../db/data.txt', 'a');
        fwrite($f, $name . ' | ' . $value . "\n");
        fclose($f);
    }

    //отображает указанный шаблон с заранее сохраненными данными
    public function display($template)
    {
        require_once $template;

        $urlRend = './../db/data.txt';
        $guestBook = $this->render($urlRend);

        foreach($guestBook as $item) {
            echo $item . '<br>';
        }
    }

    //аналогичен методу display(), но не выводит шаблон с данными в браузер, а возвращает его
    public function render($template)
    {
        $text = file_get_contents(__DIR__ . $template);
        return $this->data = explode("\n", $text);
    }
}