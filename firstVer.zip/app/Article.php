<?php
class Article extends News
{
    public function wholePage($id)
    {
        $this->render(__DIR__ . './../db/news.txt');
        return $this->news[$id];
    }
}