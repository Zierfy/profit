<?php
class News
{
    protected $news;
    public function __construct()
    {
    }
    //запись новостей в переменную
    public function render($url)
    {
        $text = explode("|||", file_get_contents($url));
        $i = 0;

        foreach ($text as $item) {
            $this->news[$i] = explode("\n", trim($item));
            $i++;
        }
        unset($this->news[count($this->news) - 1]);

    }
    public function dispDates() {
        $i = 0;
        foreach ($this->news as $item) {
            echo $item[0] . '&nbsp' . '|' . '&nbsp';?><a href='./../template/article.php?id=<?=$i?>'>--></a><br><?;
            $i++;
        }
    }
}
?>