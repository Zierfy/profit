<?php

$urlClass = './app/View.php';
$urlDisp = __DIR__ . './template/index.php';

require_once __DIR__ . $urlClass;

$obj = new View;

$obj->assign('Title1', 'Text1');
$obj->display($urlDisp);